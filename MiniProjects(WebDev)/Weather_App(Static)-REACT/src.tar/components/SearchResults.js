// SearchResults Component
import React from "react";

const SearchResults = () => {
  return <></>;
};

export default SearchResults;
