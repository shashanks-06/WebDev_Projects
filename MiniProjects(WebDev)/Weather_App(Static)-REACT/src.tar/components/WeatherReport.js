// WeatherReport Component
import React from "react";

const WeatherReport = () => {
  return <></>;
};

export default WeatherReport;
