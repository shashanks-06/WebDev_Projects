import React, { Component } from "react";

class App extends Component {
  render() {
    return (
      <div className="weather-app">
        <h1>WeatherWatch</h1>
      </div>
    );
  }
}

export default App;
