// Input Component
import React from "react";

const Input = () => {
  return <></>;
};

export default Input;
