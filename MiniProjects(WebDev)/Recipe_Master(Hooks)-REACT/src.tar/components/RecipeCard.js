// RecipeCard Component
import React from "react";

const RecipeCard = () => {
  return <></>;
};

export default RecipeCard;
