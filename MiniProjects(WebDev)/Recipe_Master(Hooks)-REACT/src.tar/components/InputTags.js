// InputTags Component
import React from "react";

const InputTags = () => {
  return <></>;
};

export default InputTags;
