// Text Component
import React from "react";

const Text = () => {
  return <></>;
};

export default Text;
