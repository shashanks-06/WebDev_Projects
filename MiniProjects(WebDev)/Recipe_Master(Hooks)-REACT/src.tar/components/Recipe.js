// Recipe Component
import React from "react";

const Recipe = () => {
  return <></>;
};

export default Recipe;
