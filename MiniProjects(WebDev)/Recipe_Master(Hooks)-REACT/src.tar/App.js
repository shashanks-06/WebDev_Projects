import React from "react";

const App = () => {
  return (
    <div className="recipe-meister">
      <h1>Recipe Meister</h1>
    </div>
  );
};

export default App;
